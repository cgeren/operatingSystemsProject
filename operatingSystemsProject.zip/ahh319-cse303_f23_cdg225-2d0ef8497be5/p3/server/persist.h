#pragma once

#include <string>
#include <vector>

/// The purpose of this file is to allow you to declare helper functions that
/// simplify interacting with persistent storage.