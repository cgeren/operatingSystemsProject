#include <cstdio>
#include <string>
#include <unistd.h>
#include <vector>

#include "persist.h"

using namespace std;

/// The purpose of this file is to allow you to define helper functions that
/// simplify interacting with persistent storage.