#include <cassert>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#include "../common/contextmanager.h"
#include "../common/crypto.h"
#include "../common/err.h"
#include "../common/net.h"
#include "../common/protocol.h"

#include "parsing.h"
#include "responses.h"

using namespace std;

/// When a new client connection is accepted, this code will run to figure out
/// what the client is requesting, and to dispatch to the right function for
/// satisfying the request.
///
/// @param sd      The socket on which communication with the client takes place
/// @param pri     The private key used by the server
/// @param pub     The public key file contents, to possibly send to the client
/// @param storage The Storage object with which clients interact
///
/// @return true if the server should halt immediately, false otherwise
bool parse_request(int sd, EVP_PKEY *pri, const vector<uint8_t> &pub,
                   Storage *storage) {
  cout << "parsing.cc::parse_request() is not implemented\n";

  // NB: These assertions are only here to prevent compiler warnings
  assert(pri);
  assert(storage);
  assert(pub.size() > 0);
  assert(sd);

  return false;
}
