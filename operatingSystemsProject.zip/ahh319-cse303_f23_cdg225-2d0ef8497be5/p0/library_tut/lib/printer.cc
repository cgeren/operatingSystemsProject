#include <iostream>

#include "printer.h"

void printSomething(std::string message) {
     std::cout << "The message is: `" << message << "`" << std::endl;
}