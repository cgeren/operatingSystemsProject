#include "printer.h"

/// Use the `printSomething` function to print "Hello World"
int main() { printSomething("Hello World"); }