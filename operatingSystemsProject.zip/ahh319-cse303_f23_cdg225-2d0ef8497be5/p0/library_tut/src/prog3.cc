// Note: we are using `<>` syntax to indicate where the printer.h file is
#include <printer.h>

/// Use the `printSomething` function to print "Hello World"
int main() { printSomething("Hello World"); }