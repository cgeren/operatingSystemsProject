#pragma once

#include <string>

/// Print the menu options
void menu(std::string current_text);